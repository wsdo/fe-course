<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            for ($i=0; $i < 20; $i++) {
                echo "<div><p>stark</p></div>";
            }
        ?>
    </body>
</html>
