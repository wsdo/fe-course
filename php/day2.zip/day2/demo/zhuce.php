<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <form class="" action="sign.php" method="post">
            <p>用户名</p><input type="text" name="name" value="">
            <p>密码</p><input type="password" name="password" value="">
            <p>邮箱</p><input type="email" name="email" value="">
            <p>年龄</p><input type="num" name="age" value="">
            <p>性别</p>
            男<input type="radio" name="sex" value="1">
            女<input type="radio" name="sex" value="2">
            <p><input type="submit" /></p>
        </form>
    </body>
</html>
