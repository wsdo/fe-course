fuxi
1.环境
xampp

    Apache web服务器
    m mysql
    p php

lamp 环境 Linux  Apache mysql php
lnmp 环境 Linux  nginx  mysql php

Linux ：  Debian Ubuntu centos 开源

        Redhat 红帽商业的



web服务器:
    nginx
    apache


执行 localhost
ipconfig 查看ip的命令
ip
192.168.1.1 局域网 在一个局域网内可以相互访问 cs内网可以一块玩
127.0.0.1 这个本地ip 只有你本地可以访问

php
$ 定义一个变量用 美元符号 区分大小写

数组创建方式

可以是用 array []
$arr = array('stark','shudong');
$arr = ['stark','shudong'];

拼接符号： . 点符号 js中用+ 加号

html 和php 混编
此时一片懵逼

Post 表单提交 amazing

创建数据库
字符集
utf8mb4 -- UTF-8 Unicode
排序规则
utf8mb4_general_ci
